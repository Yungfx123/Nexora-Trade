NEXORA TRADE — PHP/MySQL prototype
Upload contents to a PHP host, create a MySQL database, import database.sql with phpMyAdmin, then edit config.php.
index.php is the landing page; admin/ is the admin area.
The current UI contains demo data and paper-trading interactions. Production use requires secure authenticated database logic, CSRF protection, authorization, rate limits, audit logs, real payment/trading integrations, and applicable compliance/licensing.
Never collect seed phrases or private keys.
